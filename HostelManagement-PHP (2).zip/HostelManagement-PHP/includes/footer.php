<footer class="footer text-center text-muted">
 <?php echo date("Y"); ?> - Hostel Management System 